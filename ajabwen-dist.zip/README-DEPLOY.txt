ملفات البناء الجاهزة للإنتاج (Production Build) - تطبيق عجب وين في؟

هذه الحزمة جاهزة للرفع المباشر إلى استضافة cPanel:
1. ارفع محتويات هذا الملف المضغوط مباشرة إلى المسار:
   public_html/storeact/
2. تأكد من وجود ملف .htaccess (الملفات المخفية في cPanel File Manager).
3. سيعمل التطبيق على المسار:
   https://yourdomain.com/storeact/
   وسيقوم بالاتصال بالـ API على:
   https://yourdomain.com/storeact/backend/api
